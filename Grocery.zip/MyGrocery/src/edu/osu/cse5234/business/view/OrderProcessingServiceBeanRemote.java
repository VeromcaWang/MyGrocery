package edu.osu.cse5234.business.view;

public interface OrderProcessingServiceBeanRemote {

}
